#!/bin/bash
cd build
rm -rf CMakeCache.txt  CMakeFiles  cmake_install.cmake  Makefile
cmake ..
make $1
cd ..