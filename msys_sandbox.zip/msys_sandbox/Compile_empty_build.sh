#!/bin/bash
## export LD_LIBRARY_PATH=/home/tingchangyin/pkg/SuiteSparse-master/lib:$LD_LIBRARY_PATH
cd build
rm -rf CMakeCache.txt  CMakeFiles  cmake_install.cmake  Makefile
cmake ..
make $1
cd ..