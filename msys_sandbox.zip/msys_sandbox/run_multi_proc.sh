#!/bin/bash
log_text="log_MC_"$(printf "%0.5d" $1)".txt"
./DFN_multi_proc $1 > $log_text