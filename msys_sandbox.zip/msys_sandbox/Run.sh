#!/bin/bash
cd ./bin
./$1 $2
cd ..
