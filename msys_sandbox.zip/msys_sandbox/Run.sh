#!/bin/bash
cd ./bin
./DFN_main
cd ..
