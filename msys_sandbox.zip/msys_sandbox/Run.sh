#!/bin/bash
cd ./bin
./$1 $2 $3
cd ..
