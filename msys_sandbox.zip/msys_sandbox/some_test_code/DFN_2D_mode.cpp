#include "DFN_H/Load_a_DFN_from_matfile.h"
#include "DFN_H/Loop_DFN_WL.h"
#include "FEM_H/MHFEM.h"
#include "Geometry_H/Intersection_Frac_boost.h"
#include "Geometry_H/Polygon_convex_2D_with_traces.h"
#include "Geometry_H/Splitting_Polygon_convex_2D_with_traces.h"
//#include "Mesh_H/MHFEM_edge_numbering/GLOB_edge_numbering.h"
//#include "Mesh_H/MHFEM_edge_numbering/MAT_plot_SEP_GLOB_edges.h"
//#include "Mesh_H/MHFEM_edge_numbering/SEP_edge_numbering.h"
#include "Mesh_H/Mesh_DFN_linear.h"
#include "Mesh_H/Mesh_Polygon_2D_with_traces.h"
#include <chrono>
#include <iostream>
#include <sys/time.h>

int main(int argc, char *argv[])
{
    try
    {
        std::vector<std::vector<Vector3d>> verts;
        DFN::Load_a_DFN_from_matfile loadmat("../inp/Fractures.mat", verts);

        const gsl_rng_type *T;
        gsl_rng *random_seed;
        struct timeval tv;
        gettimeofday(&tv, 0);
        unsigned long mySeed = tv.tv_sec + tv.tv_usec;
        T = gsl_rng_default;
        random_seed = gsl_rng_alloc(T);
        gsl_rng_set(random_seed, mySeed);

        DFN::Domain dom;
        Vector6d modelsize;
        modelsize << -20, 20, -20, 20, -20, 20;
        dom.mode_2D = true;
        //dom.Create_whole_model_II(modelsize, verts);

        dom.Create_whole_model(atoi(argv[1]),
                               {1},
                               random_seed,
                               modelsize,
                               "uniform",
                               "single",
                               {Vector2d(-20, 20), Vector2d(-20, 20), Vector2d(-20, 20)},
                               {Vector4d(10, 0, 0, 0)},
                               {Vector7d(0, 0, 0, 0, 0, 0, 0)},
                               "constant");

        dom.Identify_percolation_clusters();

        dom.Connectivity_analysis();
        dom.Re_identify_intersection_considering_trimmed_frac();
        dom.Identify_percolation_clusters();
        /*
        for (size_t i = 0; i < dom.Fractures.size(); ++i)
        {
            size_t len = dom.Fractures[i].Verts_trim.size();

            for (size_t j = 0; j < len; j++)
            {
                cout << dom.Fractures[i].Verts_trim[j](0) << ", ";
                cout << dom.Fractures[i].Verts_trim[j](1) << ", ";
                cout << dom.Fractures[i].Verts_trim[j](2) << "\n";
            }
            cout << "-----------------\n";
        }*/
        //dom.Matlab_Out_Frac_matfile("Fractures.mat");

        //cout << 2 << endl;
        dom.PlotMatlab_DFN_and_Intersection("DFN_intersect.m");
        //dom.PLotMatlab_DFN_Cluster_along_a_direction("zzzz.m", "z");
        dom.Matlab_Out_Frac_matfile("Fractures.mat");

        DFN::Mesh_DFN_linear mesh(dom, 3, 7, 2, 1);
        //cout << mesh.element_3D << endl;
        mesh.Matlab_plot("mesh_DFN_linear.mat", "mesh_DFN_linear_command.m", dom);

        DFN::MHFEM fem{mesh, dom, 500, 20, 2, 9};
        fem.Matlab_plot("MHFEM.mat", "MHFEM.m", mesh, dom);

        cout << "MHFEM\n";
        cout << "Q_in: " << fem.Q_in << endl;
        cout << "Q_out: " << fem.Q_out << endl;
        cout << "Permeability: " << fem.Permeability << endl;
        cout << "mean edge: " << mesh.mean_edge_length << endl;
        cout << "max edge: " << mesh.max_edge_length << endl;
        cout << "min edge: " << mesh.min_edge_length << endl;

        gsl_rng_free(random_seed);
    }
    catch (Error_throw_ignore e)
    {
        cout << "\033[31mIgnore now! Because:\n";
        cout << e.msg << "\033[0m" << endl;
    }
    catch (...)
    {
    }
    return 0;
}