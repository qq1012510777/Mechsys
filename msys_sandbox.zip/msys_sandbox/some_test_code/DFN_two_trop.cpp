#include "DFN_H/Load_a_DFN_from_matfile.h"
#include "DFN_H/Loop_DFN_WL.h"
#include "FEM_H/MHFEM.h"
#include "Geometry_H/Intersection_Frac_boost.h"
#include "Geometry_H/Polygon_convex_2D_with_traces.h"
#include "Geometry_H/Splitting_Polygon_convex_2D_with_traces.h"
//#include "Mesh_H/MHFEM_edge_numbering/GLOB_edge_numbering.h"
//#include "Mesh_H/MHFEM_edge_numbering/MAT_plot_SEP_GLOB_edges.h"
//#include "Mesh_H/MHFEM_edge_numbering/SEP_edge_numbering.h"
#include "Mesh_H/Mesh_DFN_linear.h"
#include "Mesh_H/Mesh_Polygon_2D_with_traces.h"
#include <chrono>
#include <iostream>
#include <sys/time.h>

int main(int argc, char *argv[])
{
    std::vector<std::vector<Vector3d>> verts(2);

    //two trapezoidal fracture
    verts[0].resize(4);
    verts[0][0] << 8., -30.0, 21.;
    verts[0][1] << 8., 30.0, 21.;
    verts[0][2] << -8, 5.0, -21.;
    verts[0][3] << -8, -5.0, -21.;
    //
    verts[1].resize(4);
    verts[1][0] << 8., -30.0, -21.;
    verts[1][1] << 8., 30.0, -21.;
    verts[1][2] << -8, 5.0, 21.;
    verts[1][3] << -8, -5.0, 21.;

    try
    {
        for (size_t i = 0; i < 11; i++)
        {
            DFN::Domain dom;
            Vector6d modelsize;
            modelsize << -20, 20, -20, 20, -20, 20;

            std::vector<std::vector<Vector3d>> verts_u(2);
            verts_u[0] = verts[0];
            verts_u[1] = verts[1];
            dom.Create_whole_model_II(modelsize, verts_u);

            dom.Identify_percolation_clusters();

            dom.Connectivity_analysis();
            dom.Re_identify_intersection_considering_trimmed_frac();
            dom.Identify_percolation_clusters();
            dom.PlotMatlab_DFN_and_Intersection("Two_trp_DFN_intersect_" + to_string(i) + ".m");
            DFN::Mesh_DFN_linear mesh(dom, 51 - i * 5, 53 - i * 5, 2, 1);

            //mesh.Matlab_plot("mesh_DFN_linear.mat", "mesh_DFN_linear_command.m", dom);

            DFN::MHFEM fem{mesh, dom, 100, 0, 2};
            fem.Matlab_plot("Two_trp_MHFEM_" + to_string(i) + ".mat", "Two_trp_MHFEM_" + to_string(i) + ".m", mesh, dom);

            cout << "i = " << i << endl;
            cout << "Q_in: " << fem.Q_in << endl;
            cout << "Q_out: " << fem.Q_out << endl;
            cout << "Permeability: " << fem.Permeability << endl;
            cout << "mean edge: " << mesh.mean_edge_length << endl;
            cout << "max edge: " << mesh.max_edge_length << endl;
            cout << "min edge: " << mesh.min_edge_length << endl;
            cout << "inlet_length: " << fem.inlet_length << endl;
            cout << "outlet_length: " << fem.outlet_length << endl;
            cout << "\n\n";
        }
    }
    catch (Error_throw_ignore e)
    {
        cout << "\033[31mIgnore now! Because:\n";
        cout << e.msg << "\033[0m" << endl;
    }

    return 0;
}