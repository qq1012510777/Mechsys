#include "DFN_H/Load_a_DFN_from_matfile.h"
#include "DFN_H/Loop_DFN_WL.h"
#include "FEM_H/MHFEM.h"
#include "Geometry_H/Intersection_Frac_boost.h"
#include "Geometry_H/Polygon_convex_2D_with_traces.h"
#include "Geometry_H/Splitting_Polygon_convex_2D_with_traces.h"
//#include "Mesh_H/MHFEM_edge_numbering/GLOB_edge_numbering.h"
//#include "Mesh_H/MHFEM_edge_numbering/MAT_plot_SEP_GLOB_edges.h"
//#include "Mesh_H/MHFEM_edge_numbering/SEP_edge_numbering.h"
#include "Mesh_H/Mesh_DFN_linear.h"
#include "Mesh_H/Mesh_Polygon_2D_with_traces.h"
#include <chrono>
#include <iostream>
#include <sys/time.h>

int main(int argc, char *argv[])
{
    std::vector<double> Bounding_R(1);
    std::vector<double> NUM_FRAC(1);
    size_t yt = 13;
    MatrixXd Per;
    Per = MatrixXd::Zero(yt, 8);

    MatrixXd edge_size;
    edge_size = MatrixXd::Zero(yt, 2);
    edge_size.row(0) << 15, 20;
    edge_size.row(1) << 10, 11;
    edge_size.row(2) << 7, 8;
    edge_size.row(3) << 4, 5;
    edge_size.row(4) << 2, 3;
    edge_size.row(5) << 1.5, 2;
    edge_size.row(6) << 1, 1.7;
    edge_size.row(7) << 1, 1.5;
    edge_size.row(8) << 0.5, 1.3;
    edge_size.row(9) << 0.5, 1;
    edge_size.row(10) << 0.1, 0.5;
    edge_size.row(11) << 0.1, 0.2;
    edge_size.row(12) << 0.005, 0.1;

    std::vector<std::vector<Vector3d>> verts(2);
    verts[0].resize(4);
    verts[0][0] << 8., -30.0, 21.;
    verts[0][1] << 8., 30.0, 21.;
    verts[0][2] << 8, 5.0, -21.;
    verts[0][3] << 8, -5.0, -21.;
    verts[1].resize(4);
    verts[1][0] << -8., -30.0, 21.;
    verts[1][1] << -8., 30.0, 21.;
    verts[1][2] << -8, 5.0, -21.;
    verts[1][3] << -8, -5.0, -21.;

    //verts[0].resize(4);
    //verts[0][0] << 8., -30.0, 21.;
    //verts[0][1] << 8., 30.0, 21.;
    //verts[0][2] << 8, 35.0, -21.;
    //verts[0][3] << 8, -35.0, -21.;
    //verts[1].resize(4);
    //verts[1][0] << -8., -30.0, 21.;
    //verts[1][1] << -8., 30.0, 21.;
    //verts[1][2] << -8, 35.0, -21.;
    //verts[1][3] << -8, -35.0, -21.;
    try
    {

        const gsl_rng_type *T;
        gsl_rng *random_seed;
        struct timeval tv;
        gettimeofday(&tv, 0);
        unsigned long mySeed = tv.tv_sec + tv.tv_usec;
        T = gsl_rng_default;
        random_seed = gsl_rng_alloc(T);
        gsl_rng_set(random_seed, mySeed);

        DFN::Domain dom;
        Vector6d modelsize;
        modelsize << -20, 20, -20, 20, -20, 20;
        //dom.Create_whole_model_II(modelsize, verts);

        double R_ = 7.7;

        Vector7d SER;
        SER << 0.0, 0., 0., 0., 0., 0., 0.;
         
        dom.Create_whole_model(atoi(argv[1]),
                               {1},
                               random_seed,
                               modelsize,
                               "uniform",
                               "single",
                               {Vector2d(-20, 20), Vector2d(-20, 20), Vector2d(-20, 20)},
                               {Vector4d(R_, 0., 0., 0.)},
                               {SER},
                               "constant");

        dom.Identify_percolation_clusters();

        dom.Connectivity_analysis();
        dom.Re_identify_intersection_considering_trimmed_frac();
        dom.Identify_percolation_clusters();

        //cout << 2 << endl;
        dom.PlotMatlab_DFN_and_Intersection("DFN_intersect.m");
        //dom.PLotMatlab_DFN_Cluster_along_a_direction("zzzz.m", "z");

        for (size_t i = 0; i < yt; ++i)
        {
            DFN::Mesh_DFN_linear mesh(dom, edge_size(i, 0), edge_size(i, 1), 2, 1);
            //cout << mesh.element_3D << endl;
            mesh.Matlab_plot("mesh_DFN_linear.mat", "mesh_DFN_linear_command.m", dom);

            DFN::MHFEM fem{mesh, dom, 100, 0, 2, (size_t)atoi(argv[2])};
            fem.Matlab_plot("MHFEM_" + to_string(i + 1) + ".mat", "MHFEM_" + to_string(i + 1) + ".m", mesh, dom, "NO");

            cout << "i = " << i << endl;
            cout << "MHFEM\n";
            cout << "Q_in: " << fem.Q_in << endl;
            cout << "Q_out: " << fem.Q_out << endl;
            cout << "Permeability: " << fem.Permeability << endl;
            cout << "mean edge: " << mesh.mean_edge_length << endl;
            cout << "max edge: " << mesh.max_edge_length << endl;
            cout << "min edge: " << mesh.min_edge_length << endl;
            cout << "inlet_length: " << fem.inlet_length << endl;
            cout << "outlet_length: " << fem.outlet_length << endl;
            cout << "\n";

            if (isnan(fem.pressure_interior_edge(0, 0)) == true)
            {
                dom.Matlab_Out_Frac_matfile("Fractures.mat");
                string AS = "NaN result!\n";
                //cout << AS << endl;
                throw Error_throw_ignore(AS);
            }

            Per(i, 0) = fem.Permeability;
            Per(i, 1) = mesh.mean_edge_length;
            Per(i, 2) = mesh.max_edge_length;
            Per(i, 3) = mesh.min_edge_length;
            Per(i, 4) = fem.inlet_length;
            Per(i, 5) = fem.outlet_length;
            Per(i, 6) = fem.Q_in;
            Per(i, 7) = fem.Q_out;

            Bounding_R[0] = R_; //pow(pow(20, 2) * 3, 0.5);
            NUM_FRAC[0] = dom.Fractures.size();
        }
        gsl_rng_free(random_seed);
    }
    catch (Error_throw_ignore e)
    {
        cout << "\033[31mIgnore now! Because:\n";
        cout << e.msg << "\033[0m" << endl;
    }
    catch (Error_throw_pause e)
    {
        cout << "\033[31mIgnore now! Because:\n";
        cout << e.msg << "\033[0m" << endl;
    }

    std::vector<double> Permeability(&(Per.col(0)(0, 0)), Per.col(0).data() + Per.col(0).rows());
    std::vector<double> mean_edge_length(&(Per.col(1)(0, 0)), Per.col(1).data() + Per.col(1).rows());
    std::vector<double> max_edge_length(&(Per.col(2)(0, 0)), Per.col(2).data() + Per.col(2).rows());
    std::vector<double> min_edge_length(&(Per.col(3)(0, 0)), Per.col(3).data() + Per.col(3).rows());
    std::vector<double> inlet_length(&(Per.col(4)(0, 0)), Per.col(4).data() + Per.col(4).rows());
    std::vector<double> outlet_length(&(Per.col(5)(0, 0)), Per.col(5).data() + Per.col(5).rows());
    std::vector<double> Q_in(&(Per.col(6)(0, 0)), Per.col(6).data() + Per.col(6).rows());
    std::vector<double> Q_out(&(Per.col(7)(0, 0)), Per.col(7).data() + Per.col(7).rows());

    DFN::MATLAB_DATA_API M1;
    string matfile = "Bound_R_" + to_string_with_precision(Bounding_R[0], 2) + "_num_frac_" + To_string_with_width(NUM_FRAC[0], 4) + ".mat";
    M1.Write_mat(matfile, "w", Permeability.size(), Permeability.size(), 1, Permeability, "Permeability");

    M1.Write_mat(matfile, "u", mean_edge_length.size(), mean_edge_length.size(), 1, mean_edge_length, "mean_edge_length");
    M1.Write_mat(matfile, "u", max_edge_length.size(), max_edge_length.size(), 1, max_edge_length, "max_edge_length");
    M1.Write_mat(matfile, "u", min_edge_length.size(), min_edge_length.size(), 1, min_edge_length, "min_edge_length");
    M1.Write_mat(matfile, "u", inlet_length.size(), inlet_length.size(), 1, inlet_length, "inlet_length");
    M1.Write_mat(matfile, "u", outlet_length.size(), outlet_length.size(), 1, outlet_length, "outlet_length");
    M1.Write_mat(matfile, "u", Q_in.size(), Q_in.size(), 1, Q_in, "Q_in");
    M1.Write_mat(matfile, "u", Q_out.size(), Q_out.size(), 1, Q_out, "Q_out");
    M1.Write_mat(matfile, "u", Bounding_R.size(), Bounding_R.size(), 1, Bounding_R, "Bounding_R");
    M1.Write_mat(matfile, "u", NUM_FRAC.size(), NUM_FRAC.size(), 1, NUM_FRAC, "NUM_FRAC");

    return 0;
}