#include "DFN_H/Load_a_DFN_from_matfile.h"
#include "DFN_H/Loop_DFN_WL.h"
#include "FEM_H/MHFEM.h"
#include "Geometry_H/Intersection_Frac_boost.h"
#include "Geometry_H/Polygon_convex_2D_with_traces.h"
#include "Geometry_H/Splitting_Polygon_convex_2D_with_traces.h"
//#include "Mesh_H/MHFEM_edge_numbering/GLOB_edge_numbering.h"
//#include "Mesh_H/MHFEM_edge_numbering/MAT_plot_SEP_GLOB_edges.h"
//#include "Mesh_H/MHFEM_edge_numbering/SEP_edge_numbering.h"
#include "Mesh_H/Mesh_DFN_linear.h"
#include "Mesh_H/Mesh_Polygon_2D_with_traces.h"
#include <chrono>
#include <iostream>
#include <sys/time.h>

int main(int argc, char *argv[])
{
    std::vector<std::vector<Vector3d>> verts(20);

    verts[0].resize(4);
    verts[0][0] << 10., -20.0, 20.;
    verts[0][1] << 10., 20.0, 20.;
    verts[0][2] << -0., 20.0, -20.;
    verts[0][3] << -0., -20.0, -20.;
    ////
    verts[1].resize(4);
    verts[1][0] << 0., -20.0, 20.;
    verts[1][1] << 0., 20.0, 20.;
    verts[1][2] << -14., 20.0, -20.;
    verts[1][3] << -14., -20.0, -20.;

    //intersect cross
    verts[2].resize(4);
    verts[2][0] << 20., 0.0, 20.;
    verts[2][1] << -20., 0.0, 20.;
    verts[2][2] << -20., 0.0, -20.;
    verts[2][3] << 20., 0.0, -20.;
    ////
    verts[3].resize(4);
    verts[3][0] << 0., -20.0, 20.;
    verts[3][1] << 0., 20.0, 20.;
    verts[3][2] << 0., 20.0, -20.;
    verts[3][3] << 0., -20.0, -20.;

    //parallel
    verts[4].resize(4);
    verts[4][0] << 20., 0.0, 20.;
    verts[4][1] << -20., 0.0, 20.;
    verts[4][2] << -20., 0.0, -20.;
    verts[4][3] << 20., 0.0, -20.;
    verts[5].resize(4);
    verts[5][0] << 20., 10.0, 20.;
    verts[5][1] << -20., 10.0, 20.;
    verts[5][2] << -20., 10.0, -20.;
    verts[5][3] << 20., 10.0, -20.;
    //imcomplete

    verts[6].resize(4);
    verts[6][0] << 8., -20.0, 20.;
    verts[6][1] << 8., 20.0, 20.;
    verts[6][2] << -2.6667, 20.0, -6.6667;
    verts[6][3] << -2.6667, -20.0, -6.6667;
    verts[7].resize(4);
    verts[7][0] << -2.6667, -20.0, 6.6667;
    verts[7][1] << -2.6667, 20.0, 6.6667;
    verts[7][2] << 8, 20.0, -20.;
    verts[7][3] << 8, -20.0, -20.;

    verts[8].resize(4);
    verts[8][0] << 8., -20.0, 20.;
    verts[8][1] << 8., 20.0, 20.;
    verts[8][2] << -8, 20.0, -20.;
    verts[8][3] << -8, -20.0, -20.;
    verts[9].resize(4);
    verts[9][0] << -8, -20.0, 20.;
    verts[9][1] << -8, 20.0, 20.;
    verts[9][2] << 8, 20.0, -20.;
    verts[9][3] << 8, -20.0, -20.;

    verts[10].resize(4);
    verts[10][0] << 8., -20.0, 20.;
    verts[10][1] << 8., 20.0, 20.;
    verts[10][2] << -8, 20.0, -10.;
    verts[10][3] << -8, -20.0, -10.;
    verts[11].resize(4);
    verts[11][0] << -8, -20.0, 10.;
    verts[11][1] << -8, 20.0, 10.;
    verts[11][2] << 8, 20.0, -20.;
    verts[11][3] << 8, -20.0, -20.;

    //two trapezoidal fracture
    verts[12].resize(4);
    verts[12][0] << 8., -30.0, 21.;
    verts[12][1] << 8., 30.0, 21.;
    verts[12][2] << -8, 5.0, -21.;
    verts[12][3] << -8, -5.0, -21.;
    //
    verts[13].resize(4);
    verts[13][0] << -8., -30.0, 21.;
    verts[13][1] << -8., 30.0, 21.;
    verts[13][2] << 8, 10.0, -21.;
    verts[13][3] << 8, -10.0, -21.;

    verts[14].resize(4);
    verts[14][0] << 0, -20, -20;
    verts[14][1] << -10, -20, 20;
    verts[14][2] << -10, 20, 20;
    verts[14][3] << 0, 20, -20;
    //
    verts[15].resize(4);
    verts[15][0] << 0, -20, -20;
    verts[15][1] << 0, 20, -20;
    verts[15][2] << 10, 20, 20;
    verts[15][3] << 10, -20, 20;

    verts[16].resize(4);
    verts[16][0] << 0, -20, -20;
    verts[16][1] << 0, -20, 20;
    verts[16][2] << 10, 20, 20;
    verts[16][3] << 10, 20, -20;
    //
    verts[17].resize(4);
    verts[17][0] << 0, -20, -20;
    verts[17][1] << 0, -20, 20;
    verts[17][2] << -10, 20, 20;
    verts[17][3] << -10, 20, -20;

    verts[18].resize(4);
    verts[18][0] << 20., 0.0, 20.;
    verts[18][1] << -20., 0.0, 20.;
    verts[18][2] << -20., 0.0, -20.;
    verts[18][3] << 20., 0.0, -20.;
    ////
    verts[19].resize(4);
    verts[19][0] << 0., -2.0, 20.;
    verts[19][1] << 0., 2.0, 20.;
    verts[19][2] << 0., 2.0, 18.0;
    verts[19][3] << 0., -2.0, 18.0;

    for (size_t i = 0; i < verts.size(); i = i + 2)
    {
        try
        {
            DFN::Domain dom;
            Vector6d modelsize;
            modelsize << -20, 20, -20, 20, -20, 20;

            std::vector<std::vector<Vector3d>> verts_u(2);
            verts_u[0] = verts[i];
            verts_u[1] = verts[i + 1];
            dom.Create_whole_model_II(modelsize, verts_u);

            dom.Identify_percolation_clusters();

            dom.Connectivity_analysis();
            dom.Re_identify_intersection_considering_trimmed_frac();
            dom.Identify_percolation_clusters();
            dom.PlotMatlab_DFN_and_Intersection("DFN_intersect_" + to_string(i) + ".m");
            DFN::Mesh_DFN_linear mesh(dom, 10, 15, 2, 1);

            //mesh.Matlab_plot("mesh_DFN_linear.mat", "mesh_DFN_linear_command.m", dom);

            DFN::MHFEM fem{mesh, dom, 100, 0, 2, 5};
            fem.Matlab_plot("MHFEM_" + to_string(i) + ".mat", "MHFEM_" + to_string(i) + ".m", mesh, dom);

            cout << "i = " << i << endl;
            cout << "MHFEM\n";
            cout << "Q_in: " << fem.Q_in << endl;
            cout << "Q_out: " << fem.Q_out << endl;
            cout << "Permeability: " << fem.Permeability << endl;
            cout << "mean edge: " << mesh.mean_edge_length << endl;
            cout << "max edge: " << mesh.max_edge_length << endl;
            cout << "min edge: " << mesh.min_edge_length << endl;
            cout << "inlet_length: " << fem.inlet_length << endl;
            cout << "outlet_length: " << fem.outlet_length << endl;
            cout << "\n\n";
        }
        catch (Error_throw_ignore e)
        {
            cout << "\033[31mIgnore now! Because:\n";
            cout << e.msg << "\033[0m" << endl;
        }
        catch (Error_throw_pause e)
        {
            cout << "\033[31mIgnore now! Because:\n";
            cout << e.msg << "\033[0m" << endl;
        }
        catch (...)
        {
        }
    }

    try
    {
        verts.resize(2);
        //two trapezoidal fracture
        verts[0].resize(4);
        verts[0][0] << 8., -30.0, 21.;
        verts[0][1] << 8., 30.0, 21.;
        verts[0][2] << -8, 5.0, -21.;
        verts[0][3] << -8, -5.0, -21.;
        //
        verts[1].resize(4);
        verts[1][0] << -8., -30.0, 21.;
        verts[1][1] << -8., 30.0, 21.;
        verts[1][2] << 8, 10.0, -21.;
        verts[1][3] << 8, -10.0, -21.;

        DFN::Domain dom;
        Vector6d modelsize;
        modelsize << -20, 20, -20, 20, -20, 20;
        dom.Create_whole_model_II(modelsize, verts);

        dom.Identify_percolation_clusters();

        dom.Connectivity_analysis();
        dom.Re_identify_intersection_considering_trimmed_frac();
        dom.Identify_percolation_clusters();

        //dom.PlotMatlab_DFN_and_Intersection("hk5k.m");
        //dom.PLotMatlab_DFN_Cluster_along_a_direction("zzzz.m", "z");

        DFN::Mesh_DFN_overall mesh(dom, 5, 10, 2, 1);
        //mesh.Matlab_plot("mesh_DFN_FEM.mat", "mesh_DFN_FEM.m", dom);
        //cout << "mesh_finished!\n";
        DFN::FEM_DFN_A fem(mesh, dom, 2);

        fem.matlab_plot("FEM_DFN_general.mat", "FEM_DFN_general.m", dom, mesh);
        cout << "General FEM\n";
        cout << "Q_in: " << fem.Q_in << endl;
        cout << "Q_out: " << fem.Q_out << endl;
        cout << "Permeability: " << fem.Permeability << endl;
        cout << "\n";
    }
    catch (...)
    {
    }

    verts.resize(0);
    DFN::Load_a_DFN_from_matfile loadmat("../inp/Fractures.mat", verts);
    try
    {
        const gsl_rng_type *T;
        gsl_rng *random_seed;
        struct timeval tv;
        gettimeofday(&tv, 0);
        unsigned long mySeed = tv.tv_sec + tv.tv_usec;
        T = gsl_rng_default;
        random_seed = gsl_rng_alloc(T);
        gsl_rng_set(random_seed, mySeed);

        DFN::Domain dom;
        Vector6d modelsize;
        double L = 45;
        modelsize << -0.5 * L, 0.5 * L, -0.5 * L, 0.5 * L, -0.5 * L, 0.5 * L;
        dom.Create_whole_model_II(modelsize, verts);

        /*dom.Create_whole_model(atoi(argv[1]),
                               {1},
                               random_seed,
                               modelsize,
                               "uniform",
                               "single",
                               {Vector2d(-20, 20), Vector2d(-20, 20), Vector2d(-20, 20)},
                               {Vector4d(10, 0, 0, 0)},
                               {Vector7d(0, 0, 0, 0, 0, 0, 0)},
                               "constant");*/

        dom.Identify_percolation_clusters();

        dom.Connectivity_analysis();
        dom.Re_identify_intersection_considering_trimmed_frac();
        dom.Identify_percolation_clusters();
        /*
        for (size_t i = 0; i < dom.Fractures.size(); ++i)
        {
            size_t len = dom.Fractures[i].Verts_trim.size();

            for (size_t j = 0; j < len; j++)
            {
                cout << dom.Fractures[i].Verts_trim[j](0) << ", ";
                cout << dom.Fractures[i].Verts_trim[j](1) << ", ";
                cout << dom.Fractures[i].Verts_trim[j](2) << "\n";
            }
            cout << "-----------------\n";
        }*/
        //dom.Matlab_Out_Frac_matfile("Fractures.mat");

        //cout << 2 << endl;
        dom.PlotMatlab_DFN_and_Intersection("DFN_intersect_random_k.m");
        //dom.PLotMatlab_DFN_Cluster_along_a_direction("zzzz.m", "z");

        DFN::Mesh_DFN_linear mesh(dom, 1, 1.2, 2, 1);
        //cout << mesh.element_3D << endl;
        mesh.Matlab_plot("mesh_DFN_linear_random.mat", "mesh_DFN_linear_command_random.m", dom);

        DFN::MHFEM fem{mesh, dom, 100, 0, 2, 10};
        fem.Matlab_plot("MHFEM_random.mat", "MHFEM_random.m", mesh, dom);

        cout << "MHFEM\n";
        cout << "Q_in: " << fem.Q_in << endl;
        cout << "Q_out: " << fem.Q_out << endl;
        cout << "Permeability: " << fem.Permeability << endl;
        cout << "mean edge: " << mesh.mean_edge_length << endl;
        cout << "max edge: " << mesh.max_edge_length << endl;
        cout << "min edge: " << mesh.min_edge_length << endl;
        gsl_rng_free(random_seed);
    }
    catch (Error_throw_ignore e)
    {
        cout << "\033[31mIgnore now! Because:\n";
        cout << e.msg << "\033[0m" << endl;
    }
    catch (...)
    {
    }
    return 0;
}