/************************************************************************
 * MechSys - Open Library for Mechanical Systems                        *
 * Copyright (C) 2020 Sergio Galindo                                    *
 *                                                                      *
 * This program is free software: you can redistribute it and/or modify *
 * it under the terms of the GNU General Public License as published by *
 * the Free Software Foundation, either version 3 of the License, or    *
 * any later version.                                                   *
 *                                                                      *
 * This program is distributed in the hope that it will be useful,      *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of       *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the         *
 * GNU General Public License for more details.                         *
 *                                                                      *
 * You should have received a copy of the GNU General Public License    *
 * along with this program. If not, see <http://www.gnu.org/licenses/>  *
 ************************************************************************/

// MechSys

#include <chrono>
#include <mechsys/dfn/Loop.h>
#include <mechsys/mesh/unstructured.h>

void ACC()
{

    Mesh::Unstructured mesh(2);
    mesh.Set(14, 15, 1, 0);

    mesh.SetReg(0, -1, 280.592, 0, 0);

    mesh.SetPnt(9, -9, 13.9853, 0.5944);
    mesh.SetPnt(10, -10, 3.6549, -5.5114);
    mesh.SetPnt(11, -11, -6.6755, -11.6174);

    mesh.SetPnt(0, -0, -17.006, -17.7234);
    mesh.SetPnt(1, -1, -22.8589, -7.86);
    mesh.SetPnt(2, -2, -28.7119, 2.0033);
    mesh.SetPnt(3, -3, -33.1768, 9.5275);
    mesh.SetPnt(4, -4, -22.887, 15.7021);
    mesh.SetPnt(5, -5, -12.5972, 21.8766);
    mesh.SetPnt(6, -6, -2.3074, 28.0511);
    mesh.SetPnt(7, -7, 1.6393, 21.3999);
    mesh.SetPnt(8, -8, 7.8123, 10.9972);

    //mesh.SetPnt(12, -12, -28.7119, 2.0033);  // cannot have overlaping point!!!!!
    mesh.SetPnt(12, -12, -18.5948, 8.4688);
    mesh.SetPnt(13, -13, -8.4777, 14.9344);
    //mesh.SetPnt(15, -15, 1.6393, 21.3999);

    mesh.SetSeg(0, -0, 0, 1);
    mesh.SetSeg(1, -1, 1, 2);
    mesh.SetSeg(2, -2, 2, 3);
    mesh.SetSeg(3, -3, 3, 4);
    mesh.SetSeg(4, -4, 4, 5);
    mesh.SetSeg(5, -5, 5, 6);
    mesh.SetSeg(6, -6, 6, 7);
    mesh.SetSeg(7, -7, 7, 8);
    mesh.SetSeg(8, -8, 8, 9);
    mesh.SetSeg(9, -9, 9, 10);
    mesh.SetSeg(10, -10, 10, 11);
    mesh.SetSeg(11, -11, 11, 0);

    mesh.SetSeg(12, -12, 2, 12);
    mesh.SetSeg(13, -13, 12, 13);
    mesh.SetSeg(14, -14, 13, 7);

    mesh.Generate();
    //return;
};

int main(int argc, char **argv) try
{
    for (size_t i = 0; i < 4; ++i)
        ACC();
}
MECHSYS_CATCH
