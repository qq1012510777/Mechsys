#include "DFN_H/Loop_DFN_WL.h"
#include <chrono>
#include <iostream>
#include <sys/time.h>
using namespace std;

int main()
{

    const gsl_rng_type *T;
    gsl_rng *random_seed;
    struct timeval tv;
    gettimeofday(&tv, 0);
    unsigned long mySeed = tv.tv_sec + tv.tv_usec;
    T = gsl_rng_default;
    random_seed = gsl_rng_alloc(T);
    gsl_rng_set(random_seed, mySeed);
    //gsl_rng_env_setup();

    Vector3d pnt1, pnt2, pnt3, pnt4, pnt5, pnt6;
    pnt1 << -0.170406,
        7.30233,
        16.1372;
    pnt2 << -1.57275,
        5.55434,
        18;
    pnt3 << -7.29675,
        0.858625,
        18;
    pnt4 << -9.54916,
        -0.143553,
        15.364;

    pnt5 << -5.46586,
        4.94619,
        9.93985;
    pnt6 << -0.170406,
        7.30233,
        16.1372;

    std::vector<Vector3d> F1 = {pnt1, pnt2, pnt3, pnt4, pnt5, pnt6};

    pnt1 << -1.43281,
        5.79201,
        8.44607;
    pnt2 << 0.0639579,
        -1.67621,
        12.1858;
    pnt3 << -7.37642,
        -1.14226,
        16.23;
    pnt4 << -8.87319,
        6.32596,
        12.4903;

    std::vector<Vector3d> F2 = {pnt1, pnt2, pnt3, pnt4};

    DFN::Polygon_convex_3D A{F1};
    DFN::Polygon_convex_3D B{F2};

    DFN::Intersection_Frac FY1(A, B);
    cout << "FY1 intersection:\n";
    for (size_t i = 0; i < (size_t)FY1.Intersection.size(); ++i)
        cout << FY1.Intersection[i].transpose() << endl;

    gsl_rng_free(random_seed);
    return 0;
}