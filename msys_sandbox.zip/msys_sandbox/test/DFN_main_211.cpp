#include "DFN_H/Loop_DFN_WL.h"
#include "Geometry_H/Intersection_Frac_boost.h"
#include "Geometry_H/Polygon_convex_2D_with_traces.h"
#include "Geometry_H/Splitting_Polygon_convex_2D_with_traces.h"
#include "Mesh_H/Mesh_Polygon_2D_with_traces.h"
#include <chrono>
#include <iostream>
#include <sys/time.h>

int main()
{
    const gsl_rng_type *T;
    gsl_rng *random_seed;
    struct timeval tv;
    gettimeofday(&tv, 0);
    unsigned long mySeed = tv.tv_sec + tv.tv_usec;
    T = gsl_rng_default;
    random_seed = gsl_rng_alloc(T);
    gsl_rng_set(random_seed, mySeed);

    DFN::Random_function c(random_seed);
    double YU[1000];
#pragma omp parallel for schedule(static) num_threads(10)
    for (size_t i = 0; i < 1000; i++)
    {
    Regenerate150:;
        try
        {
            double iy = c.unifrm(-1, 11);

            if (iy > 4 && iy < 6)
            {
                throw Error_throw_ignore("Error!\n");
            }
            YU[i] = iy;
        }
        catch (Error_throw_ignore e)
        {
            cout << "\033[31mRegenerate now! Because:\n"
                 << e.msg << "\033[0m" << endl;
            goto Regenerate150;
        }

        throw Error_throw_ignore("Error XXXXXX!\n");
    }

    for (size_t i = 0; i < 1000; ++i)
        cout << YU[i] << ", ";

    cout << endl;

    return 0;
}