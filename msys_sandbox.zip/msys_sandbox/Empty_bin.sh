#!/bin/bash
cd ./bin
rm -rf *