#include "DFN_H/Load_a_DFN_from_matfile.h"
#include "DFN_H/Loop_DFN_WL.h"
#include "Geometry_H/Intersection_Frac_boost.h"
#include "Geometry_H/Polygon_convex_2D_with_traces.h"
#include "Geometry_H/Splitting_Polygon_convex_2D_with_traces.h"
#include "Mesh_H/Mesh_Polygon_2D_with_traces.h"
#include <chrono>
#include <iostream>
#include <sys/time.h>

int main()
{
    auto start = std::chrono::steady_clock::now();
    /*
    std::vector<Vector3d> f1(1), f2(1);
    f1[0] << 1,0,0;
    double R_angle_temp1 = 90 * M_PI / 180.0;

    Quaternion_t Q_axis;
    Vector3d temp1;
    temp1 << 0, 0, 1;


    DFN::Rotation_verts R1(f1, R_angle_temp1, Q_axis, temp1, f2);

    cout << "f2: " << f2[0].transpose() << endl;

    exit(0);
    */
    /*
    std::vector<Vector3d> Verts_18 = {
        Vector3d{8.87459, 18, 8.57739},
        Vector3d{8.43928, 5.48634, 13.1104},
        Vector3d{-7.10818, 6.00996, 13.0628},
        Vector3d{-6.69109, 18, 8.71954}};

    std::vector<Vector3d> Verts_47 = {
        Vector3d{1.06683,
                 18,
                 -8.61405},
        Vector3d{0.329784,
                 16.6559,
                 -10.8265},
        Vector3d{-11.3354,
                 10.055,
                 -2.93014},
        Vector3d{-7.07558,
                 17.8235,
                 9.85678},
        Vector3d{-6.76357,
                 18,
                 9.64558}};
    
    DFN::Polygon_convex_3D A{Verts_18}, B{Verts_47};
    
    DFN::Intersection_Frac_boost AI{A, B};
    cout << AI.If_intersect << endl;
    cout << AI.Intersection[0].transpose() << endl;
    cout << AI.Intersection[1].transpose() << endl;
    exit(0);
    */

    /*
    Vector2d A, B, C, D, E, F, G;
    A << 19.4367, -9.53799;
    B << 9.36214, -8.39998;
    C << -18, -5.308;
    D << 18, -9.375;

    bool collinear1, collinear2;
    DFN::Collinear_2D AS1{A, B, C, collinear1};
    DFN::Collinear_2D AS2{A, B, D, collinear2};
    cout << collinear1 << ", " << collinear2 << endl;
    */
    /*

    std::vector<Vector3d> F0{Vector3d{3.67062, 11.4933, 18},
                             Vector3d{3.50803, 10.4164, 10.2726},
                             Vector3d{-4.62012, 8.03308, 10.7758},
                             Vector3d{-4.46811, 9.03985, 18}};

    std::vector<Vector3d> F1{Vector3d{-4.03344, 11.7829, 13.707},
                             Vector3d{0.203639, 5.13119, 16.8378},
                             Vector3d{-3.41509, 0.0986898, 11.0431},
                             Vector3d{-7.65217, 6.75041, 7.9123}};

    DFN::Fracture K0{0, -1, F0};
    DFN::Fracture K1{1, -1, F1};

    DFN::Polygon_convex_3D f0{K0.Verts};
    DFN::Polygon_convex_3D f1{K1.Verts};

    DFN::Intersection_Frac I1{f0, f1};

    for (size_t i = 0; i < I1.Intersection.size(); ++i)
        cout << I1.Intersection[i].transpose() << endl;

    exit(0);*/

    /*
    std::vector<Vector3d> POLYGON{Vector3d{2.60249, -5.11009, -1.88728e-06},
                                  Vector3d{-1.88548, -10.1669, 2.07045},
                                  Vector3d{-5.15234, -9.83152, -4.19175},
                                  Vector3d{-0.664364, -4.77471, -6.26221}};
    for (size_t i = 0; i < POLYGON.size(); ++i)
    {
        DFN::Line_seg_3D line_seg_3D(POLYGON[i], POLYGON[(i + 1) % POLYGON.size()]);
        Vector3d A;
        bool ty = line_seg_3D.Line_crosses_a_horizontal_plane(A);
        if (ty == true)
        {
            cout << 1 << endl;
        }
    }
    exit(0);
    
    
    std::vector<Vector3d> Verts{Vector3d{0, 0, 0}, Vector3d{100, 0, 0}, Vector3d{100, 100, 0}, Vector3d{0, 100, 0}};
    DFN::Polygon_convex_2D A{Verts};

    vector<DFN::Line_seg_2D> Traces(8);
    Traces[0].Re_constructor(Vector2d{80, 5}, Vector2d{80, 100});
    Traces[1].Re_constructor(Vector2d{50, 100}, Vector2d{50, 50});
    Traces[2].Re_constructor(Vector2d{10, 70}, Vector2d{70, 70});
    Traces[3].Re_constructor(Vector2d{50, 100}, Vector2d{10, 50});
    
    Traces[4].Re_constructor(Vector2d{0, 0}, Vector2d{10, 10});
    Traces[5].Re_constructor(Vector2d{0, 20}, Vector2d{0, 50});
    Traces[6].Re_constructor(Vector2d{20, 10}, Vector2d{40, 10});
    Traces[7].Re_constructor(Vector2d{30, 10}, Vector2d{50, 10});

    DFN::Polygon_convex_2D_with_traces_AAAA B{A, Traces};
    B.Matlab_plot("uyxx.m");

    exit(0);*/
    /*
    DFN::Splitting_Polygon_convex_2D_with_traces C{B, 10.0};

    std::vector<std::vector<std::pair<size_t, Eigen::Vector2d>>> neigh_shared_A;

    size_t NO_Nodes_p_A = 0;

    DFN::Mesh_Polygon_2D_with_traces mesh{
        C.Pnt_sets,
        C.Topo_struct,
        29,
        0.001,
        15,
        neigh_shared_A,
        NO_Nodes_p_A};

    mesh.Identifying_Frac_bound(A, Traces);
    mesh.Matlab_plot("D2mesh.m", C);
    exit(0);
    */

    /*
    std::vector<Vector3d> Verts{Vector3d{0, 0, 0}, Vector3d{100, 0, 0}, Vector3d{100, 100, 0}, Vector3d{0, 100, 0}};
    DFN::Polygon_convex_2D A{Verts};

    vector<DFN::Line_seg_2D> Traces(4);
    Traces[0].Re_constructor(Vector2d{50, 50}, Vector2d{50, 50});
    Traces[1].Re_constructor(Vector2d{40, 40}, Vector2d{40, 40});
    Traces[2].Re_constructor(Vector2d{20, 20}, Vector2d{20, 30});
    Traces[3].Re_constructor(Vector2d{20, 25}, Vector2d{30, 25});

    DFN::Polygon_convex_2D_with_traces B{A, Traces};

    DFN::Splitting_Polygon_convex_2D_with_traces C{B, 5.0, Traces};
    C.Matlab_plot("meshpp.m");

    std::vector<std::vector<std::pair<size_t, Eigen::Vector2d>>> neigh_shared_A;

    size_t NO_Nodes_p_A = 0;

    DFN::Mesh_Polygon_2D_with_traces mesh{
        C.Pnt_sets,
        C.Topo_struct,
        C.Topo_struct_attri,
        10,
        neigh_shared_A,
        NO_Nodes_p_A,
        A,
        C,
        Traces};

    mesh.Matlab_plot("D2mesh.m", C);
    exit(0);
    */
    /*
    DFN::Line_seg_2D ThisLine{
        Vector2d{-6.372, 13.5651},
        Vector2d{-5.47002, 13.0117}};

    DFN::Line_seg_2D ThisLine2{
        Vector2d{-6.372, 13.5651},
        Vector2d{-5.47002, 13.0117}};

    std::vector<Vector2d> Intersection;
    bool ifoverlap = ThisLine.If_two_lines_overlap(ThisLine2, Intersection);
    cout << ifoverlap << endl;
    exit(0);
    */

    /*
    std::vector<std::vector<Vector3d>> verts(2);
    //DFN::Load_a_DFN_from_matfile loadmat("../inp/Fractures.mat", verts);
    //verts[0].resize(4);
    //verts[0][0] << 10., -20.0, 20.;
    //verts[0][1] << 10., 20.0, 20.;
    //verts[0][2] << -0., 20.0, -20.;
    //verts[0][3] << -0., -20.0, -20.;
    ////////
    //verts[1].resize(4);
    //verts[1][0] << 0., -20.0, 20.;
    //verts[1][1] << 0., 20.0, 20.;
    //verts[1][2] << -14., 20.0, -20.;
    //verts[1][3] << -14., -20.0, -20.;

    //verts[0].resize(4);
    //verts[0][0] << 20., 0.0, 20.;
    //verts[0][1] << -20., 0.0, 20.;
    //verts[0][2] << -20., 0.0, -20.;
    //verts[0][3] << 20., 0.0, -20.;
    //////
    //verts[1].resize(4);
    //verts[1][0] << 0., -20.0, 20.;
    //verts[1][1] << 0., 20.0, 20.;
    //verts[1][2] << 0., 20.0, -20.;
    //verts[1][3] << 0., -20.0, -20.;
    //
    //verts[1].resize(4);
    //verts[1][0] << -20., -5.0, 3.;
    //verts[1][1] << -20., 5.0, 3.;
    //verts[1][2] << 20., 5.0, 3.;
    //verts[1][3] << 20., -5.0, 3.;

    //imcomplete

    //verts[0].resize(4);
    //verts[0][0] << 15., -20.0, 20.;
    //verts[0][1] << 15., 20.0, 20.;
    //verts[0][2] << 2.5, 20.0, -10.;
    //verts[0][3] << 2.5, -20.0, -10.;
    ////
    //verts[1].resize(4);
    //verts[1][0] << 4.5, -20.0, 10.;
    //verts[1][1] << 4.5, 20.0, 10.;
    //verts[1][2] << 16, 20.0, -20.;
    //verts[1][3] << 16, -20.0, -20.;

    //verts[0].resize(4);
    //verts[0][0] << 8., -20.0, 20.;
    //verts[0][1] << 8., 20.0, 20.;
    //verts[0][2] << -8, 20.0, -20.;
    //verts[0][3] << -8, -20.0, -20.;
    ////
    //verts[1].resize(4);
    //verts[1][0] << -8, -20.0, 20.;
    //verts[1][1] << -8, 20.0, 20.;
    //verts[1][2] << 8, 20.0, -20.;
    //verts[1][3] << 8, -20.0, -20.;
    //
    //verts[1].resize(4);
    //verts[1][0] << 5., -20.0, 20.;
    //verts[1][1] << 5., 20.0, 20.;
    //verts[1][2] << -11, 20.0, -20.;
    //verts[1][3] << -11, -20.0, -20.;

    //verts[0].resize(4);
    //verts[0][0] << 8., -20.0, 20.;
    //verts[0][1] << 8., 20.0, 20.;
    //verts[0][2] << -8, 20.0, -10.;
    //verts[0][3] << -8, -20.0, -10.;
    //
    //verts[1].resize(4);
    //verts[1][0] << -8, -20.0, 10.;
    //verts[1][1] << -8, 20.0, 10.;
    //verts[1][2] << 8, 20.0, -20.;
    //verts[1][3] << 8, -20.0, -20.;
    */

    /*
    std::vector<std::vector<Vector3d>> verts;
    DFN::Load_a_DFN_from_matfile loadmat("../inp/Fractures.mat", verts);
    DFN::Domain dom;
    Vector6d modelsize;
    modelsize << -20, 20, -20, 20, -20, 20;
    dom.Create_whole_model_II(modelsize, verts);

    dom.Identify_percolation_clusters();

    dom.Connectivity_analysis();
    dom.Re_identify_intersection_considering_trimmed_frac();
    dom.Identify_percolation_clusters();

    dom.PlotMatlab_DFN_and_Intersection("hk5k.m");
    dom.PLotMatlab_DFN_Cluster_along_a_direction("zzzz.m", "z");

    DFN::Mesh_DFN_overall mesh(dom, 0.7, 2, 2);
    mesh.Matlab_plot("mesh_DFN.mat", "mesh_DFN.m", dom);
    cout << "mesh_finished!\n";
    DFN::FEM_DFN_A CC(mesh, dom, 2);

    CC.matlab_plot("FEM_DFN_same.mat", "FEM_DFN_same.m", dom, mesh);

    exit(0);
    */
    //---------------------------------------------------------------

    const gsl_rng_type *T;
    gsl_rng *random_seed;
    struct timeval tv;
    gettimeofday(&tv, 0);
    unsigned long mySeed = tv.tv_sec + tv.tv_usec;
    T = gsl_rng_default;
    random_seed = gsl_rng_alloc(T);
    gsl_rng_set(random_seed, mySeed);
    //gsl_rng_env_setup();

    //----
    string orientation_distribution;
    string percolation_direction;
    string fracture_size_distriution;
    string conductivity_distri;
    double min_ele_edge;
    double max_ele_edge;
    DFN::Loop_DFN loop_1;

    size_t modelno = 0;

    std::ifstream oii("../inp/DFN_WL.inp", std::ios::in);
    if (!oii)
    {
        std::cout << "Please define an input.inp!\n";
        exit(0);
    }

    //---loop parameters
    oii >> loop_1.switch_2D; //
    oii.ignore(300, '\n');
    oii >> loop_1.Data_CommandFile; //
    oii.ignore(300, '\n');
    oii >> loop_1.Data_MatFile; //
    oii.ignore(300, '\n');

    oii >> loop_1.Model_flow; //
    oii.ignore(300, '\n');

    oii >> modelno; //
    oii.ignore(300, '\n');

    oii >> min_ele_edge; //
    oii.ignore(300, '\n');
    oii >> max_ele_edge; //
    oii.ignore(300, '\n');

    oii >> loop_1.Nproc;
    oii.ignore(300, '\n');
    oii >> loop_1.times;
    oii.ignore(300, '\n');
    oii >> loop_1.nt;
    oii.ignore(300, '\n');
    oii >> loop_1.nk;
    oii.ignore(300, '\n');
    oii >> loop_1.nv_MC_TIMES;
    oii.ignore(300, '\n');
    oii >> loop_1.Nb_flow_sim_MC_times;
    oii.ignore(300, '\n');
    oii >> loop_1.n_initial_frac_density;
    oii.ignore(300, '\n');
    oii >> loop_1.nx;
    oii.ignore(300, '\n');
    //---model size
    oii >> loop_1.L;
    oii.ignore(300, '\n');
    //---num of fracture sets
    oii >> loop_1.NumofFsets;
    oii.ignore(300, '\n');
    //---orientation distribution pattern
    oii >> orientation_distribution;
    oii.ignore(300, '\n');
    oii >> fracture_size_distriution;
    oii.ignore(300, '\n');
    oii >> percolation_direction;
    oii.ignore(300, '\n');
    oii >> conductivity_distri;
    oii.ignore(300, '\n');

    //---fracture size distribution parameters
    if (orientation_distribution == "uniform" || orientation_distribution == "orthogonal")
    {
        if (fracture_size_distriution == "powerlaw")
        {
            loop_1.array12.resize(1);
            loop_1.array12[0] = Vector4d::Zero();
            oii >> loop_1.array12[0][0];
            oii.ignore(300, '\n');
            oii >> loop_1.array12[0][1];
            oii.ignore(300, '\n');
            oii >> loop_1.array12[0][2];
            oii.ignore(300, '\n');
        }
        else if (fracture_size_distriution == "lognormal")
        {
            loop_1.array12.resize(1);
            loop_1.array12[0] = Vector4d::Zero();
            oii >> loop_1.array12[0][0];
            oii.ignore(300, '\n');
            oii >> loop_1.array12[0][1];
            oii.ignore(300, '\n');
            oii >> loop_1.array12[0][2];
            oii.ignore(300, '\n');
            oii >> loop_1.array12[0][3];
            oii.ignore(300, '\n');
        }
        else if (fracture_size_distriution == "uniform")
        {
            loop_1.array12.resize(1);
            loop_1.array12[0] = Vector4d::Zero();
            oii >> loop_1.array12[0][0];
            oii.ignore(300, '\n');
            oii >> loop_1.array12[0][1];
            oii.ignore(300, '\n');
        }
        else if (fracture_size_distriution == "single")
        {
            loop_1.array12.resize(1);
            loop_1.array12[0] = Vector4d::Zero();
            oii >> loop_1.array12[0][0];
            oii.ignore(300, '\n');
        }
    }
    else if (orientation_distribution == "fisher")
    {
        loop_1.array12.resize(loop_1.NumofFsets);
        if (fracture_size_distriution == "powerlaw")
        {
            for (size_t i = 0; i < loop_1.NumofFsets; ++i)
            {
                loop_1.array12[i] = Vector4d::Zero();
                oii >> loop_1.array12[i][0];
                oii.ignore(300, '\n');
                oii >> loop_1.array12[i][1];
                oii.ignore(300, '\n');
                oii >> loop_1.array12[i][2];
                oii.ignore(300, '\n');
            }
        }
        else if (fracture_size_distriution == "lognormal")
        {
            for (size_t i = 0; i < loop_1.NumofFsets; ++i)
            {
                loop_1.array12[i] = Vector4d::Zero();
                oii >> loop_1.array12[i][0];
                oii.ignore(300, '\n');
                oii >> loop_1.array12[i][1];
                oii.ignore(300, '\n');
                oii >> loop_1.array12[i][2];
                oii.ignore(300, '\n');
                oii >> loop_1.array12[i][3];
                oii.ignore(300, '\n');
            }
        }
        else if (fracture_size_distriution == "uniform")
        {
            for (size_t i = 0; i < loop_1.NumofFsets; ++i)
            {
                loop_1.array12[i] = Vector4d::Zero();
                oii >> loop_1.array12[i][0];
                oii.ignore(300, '\n');
                oii >> loop_1.array12[i][1];
                oii.ignore(300, '\n');
            }
        }
        else if (fracture_size_distriution == "single")
        {
            for (size_t i = 0; i < loop_1.NumofFsets; ++i)
            {
                loop_1.array12[i] = Vector4d::Zero();
                oii >> loop_1.array12[i][0];
                oii.ignore(300, '\n');
            }
        }
    }
    else
    {
        cout << "Please define orientation distribution! from DFN_main.cpp!\n";
        exit(0);
    }
    //---orientation distribution parameters
    if (orientation_distribution == "fisher")
    {
        loop_1.array13.resize(loop_1.NumofFsets);
        loop_1.DenWeight.resize(loop_1.NumofFsets);
        for (size_t i = 0; i < loop_1.NumofFsets; ++i)
        {
            oii >> loop_1.DenWeight[i];
            oii.ignore(300, '\n');
            oii >> loop_1.array13[i][0];
            oii.ignore(300, '\n');
            oii >> loop_1.array13[i][1];
            oii.ignore(300, '\n');
            oii >> loop_1.array13[i][2];
            oii.ignore(300, '\n');
            oii >> loop_1.array13[i][3];
            oii.ignore(300, '\n');
            oii >> loop_1.array13[i][4];
            oii.ignore(300, '\n');
            oii >> loop_1.array13[i][5];
            oii.ignore(300, '\n');
            oii >> loop_1.array13[i][6];
            oii.ignore(300, '\n');
        }
    }
    oii.close();

    loop_1.Loop_create_DFNs(random_seed, orientation_distribution, fracture_size_distriution, percolation_direction, min_ele_edge, max_ele_edge, conductivity_distri, modelno);

    auto end = std::chrono::steady_clock::now();
    std::chrono::duration<double, std::micro> elapsed = end - start; // std::micro time (us)
    std::cout << "Running time: " << (((double)(elapsed.count() * 1.0) * (0.000001)) / 60.00) / 60.00 << "h" << std::endl;
    gsl_rng_free(random_seed);
    return 0;
}