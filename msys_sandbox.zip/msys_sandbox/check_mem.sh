#!/bin/bash
INTERVAL=2
echo "check memory usage of $1 for every ${INTERVAL} seconds"

date | tee -a check_mem.log

x=$( (pgrep $1 | wc -l))

while [ $x -gt 0 ]; do
    ps -o rss $(pgrep $1 | head -n 1) | numfmt --header --to-unit=1048576 | tee -a check_mem.log
    x=$( (pgrep $1 | wc -l))
    sleep ${INTERVAL}
done

date | tee -a check_mem.log
